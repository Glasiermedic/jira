#!/usr/bin/env python3
"""
Pull Jira issues and publish compact project status for agents:
- docs/status.json (for machines)
- docs/status.md (for humans/GPTs)

Env vars (repo secrets recommended):
- JIRA_BASE: https://your-site.atlassian.net
- JIRA_EMAIL: you@example.com
- JIRA_API_TOKEN: <token>
- JIRA_PROJECT_KEYS: comma-separated, e.g., WDV2,DATA
- JIRA_JQLS: optional comma-separated JQLs; if provided, each is fetched
"""
import os, sys, json, datetime, textwrap, urllib.parse
import base64
import requests
from collections import defaultdict

BASE = os.environ["JIRA_BASE"]
EMAIL = os.environ["JIRA_EMAIL"]
TOKEN = os.environ["JIRA_API_TOKEN"]
PROJ_KEYS = [k.strip() for k in os.environ.get("JIRA_PROJECT_KEYS","").split(",") if k.strip()]
JQLS = [j.strip() for j in os.environ.get("JIRA_JQLS","").split(",") if j.strip()]

auth = (EMAIL, TOKEN)

def search_jql(jql, start=0, max_results=100):
    url = f"{BASE}/rest/api/3/search"
    params = {
        "jql": jql,
        "startAt": start,
        "maxResults": max_results,
        "fields": "summary,status,issuetype,priority,labels,duedate,customfield_10011,parent,assignee,updated"
    }
    r = requests.get(url, params=params, auth=auth)
    r.raise_for_status()
    return r.json()

def fetch_all(jql):
    start = 0
    issues = []
    while True:
        data = search_jql(jql, start=start)
        issues.extend(data.get("issues", []))
        if start + data.get("maxResults", 0) >= data.get("total", 0):
            break
        start += data.get("maxResults", 0)
    return issues

def simplify(issue):
    f = issue["fields"]
    def g(path, default=None):
        cur = issue
        for p in path.split("."):
            cur = cur.get(p, {}) if isinstance(cur, dict) else {}
        return cur or default
    return {
        "key": issue["key"],
        "summary": f.get("summary"),
        "type": (f.get("issuetype") or {}).get("name"),
        "status": (f.get("status") or {}).get("name"),
        "priority": (f.get("priority") or {}).get("name"),
        "labels": f.get("labels") or [],
        "assignee": (f.get("assignee") or {}).get("displayName"),
        "due": f.get("duedate"),
        "epic": f.get("customfield_10011") or ( (f.get("parent") or {}).get("key") if (f.get("parent") or {}).get("fields",{}).get("issuetype",{}).get("name") == "Epic" else None ),
        "updated": f.get("updated")
    }

def group_by_epic(issues):
    by_epic = defaultdict(list)
    for i in issues:
        by_epic[i.get("epic") or "No Epic"].append(i)
    return by_epic

def build_markdown(snapshot):
    lines = []
    lines.append(f"# Project Status — {snapshot['generated_at']}")
    for blk in snapshot["blocks"]:
        lines.append(f"\n## {blk['title']}")
        lines.append(f"_JQL_: `{blk['jql']}`  \n_Total_: **{blk['total']}**")
        epics = group_by_epic(blk["issues"])
        for epic, items in epics.items():
            lines.append(f"\n### Epic: {epic}")
            for it in items:
                due = f" (due {it['due']})" if it.get("due") else ""
                lines.append(f"- **{it['key']}** [{it['status']}] {it['summary']}{due} — {', '.join(it['labels']) if it['labels'] else ''}")
    return "\n".join(lines)

def main():
    blocks = []
    if JQLS:
        for j in JQLS:
            issues = [simplify(x) for x in fetch_all(j)]
            blocks.append({"title": "Custom", "jql": j, "total": len(issues), "issues": issues})
    else:
        for key in PROJ_KEYS:
            j = f"project = {key} ORDER BY Rank ASC"
            issues = [simplify(x) for x in fetch_all(j)]
            blocks.append({"title": f"Project {key}", "jql": j, "total": len(issues), "issues": issues})

    snapshot = {
        "generated_at": datetime.datetime.utcnow().isoformat() + "Z",
        "jira_base": BASE,
        "blocks": blocks
    }

    os.makedirs("docs", exist_ok=True)
    with open("docs/status.json", "w") as f:
        json.dump(snapshot, f, indent=2)
    with open("docs/status.md", "w") as f:
        f.write(build_markdown(snapshot))

    print("Wrote docs/status.json and docs/status.md")

if __name__ == "__main__":
    main()
