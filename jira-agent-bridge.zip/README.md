# Jira Agent Bridge

Make a single, public, **machine-readable** project status feed your GPTs can read:
- `https://<your-gh-username>.github.io/<your-repo>/status.json`
- `https://<your-gh-username>.github.io/<your-repo>/status.md`

This repo template includes:
- `scripts/build_status.py` — queries Jira Cloud REST API using JQL and emits compact **status.json** and friendly **status.md**
- GitHub Action to run **hourly** and on manual trigger
- `docs/` folder published via GitHub Pages (no extra deploy step)

## Setup (10 mins)

1) **Create a new GitHub repo** (public or private; Pages can serve from `docs/` on default branch).
2) Copy this bundle into the repo root (keep paths).
3) In **Settings → Pages**, choose **Branch: main** and **Folder: /docs**.
4) In **Settings → Secrets and variables → Actions → New repository secret**, add:
   - `JIRA_BASE` — e.g., `https://your-site.atlassian.net`
   - `JIRA_EMAIL` — your Atlassian account email
   - `JIRA_API_TOKEN` — from https://id.atlassian.com/manage-profile/security/api-tokens
   - `JIRA_PROJECT_KEYS` — comma-separated keys (e.g., `WDV2`), or leave blank and use JQLs
   - `JIRA_JQLS` — optional; comma-separated JQL filters (example below)
5) Commit → GitHub Action runs → visit **/status.json** and **/status.md** URLs.
6) Share those URLs with any GPT. They can summarize **without long back-and-forth**.

## Customize

- Edit `scripts/build_status.py`:
  - tweak fields included in `status.json`
  - adjust WIP limits, column mapping, or label filters
- Edit `.github/workflows/jira_status.yml` schedule (default: hourly).

## Example JQLs
```
project = WDV2 ORDER BY Rank ASC
project = WDV2 AND issuetype = Epic ORDER BY Rank ASC
project = WDV2 AND sprint in openSprints() ORDER BY Rank ASC
```
