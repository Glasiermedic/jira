# PROMPT_CONTRACT (v2)

Use status.json; fallback status.md. Do not browse unless asked.
Summarize per epic: In Progress, Overdue, Next actions.
Mention staleness if generated_at > 24h. Link issues using jira_base.
If story_points exists, total per epic and remaining not Done.
